// @bun
var s={fetch(e){return Response.json({message:"Hello from API Gateway!"})}};export{s as default};

//# debugId=FEB9DAB54A83B0B764756E2164756E21
//# sourceMappingURL=index.js.map
